-- * CUSTOMER RATINGS *
-- Query 1: Add New Rating
INSERT INTO Rating
VALUES (1, 6, 3.0);

-- Query 2: Update Rating
Update Rating
SET r_starRating = 4
WHERE r_custID = 3
AND r_bookid = 6;

-- Query 3: Delete Rating
DELETE FROM Rating
WHERE r_custID = 5
AND r_bookid = 8
AND r_starRating = 4.5;

-- * CUSTOMER INFORMATION *
-- Query 4: Add New Customer
INSERT INTO Customer
VALUES (8, 'Arthur Morgan', '321-654-0987', 'cowboy1889@fakeemail.com');

-- Query 5: Update Customer Information
Update Customer
SET c_custName = 'Heather Mason', c_custPhone = '123-654-7809', c_custEmail = 'itgurlllcheryl@fakeemail.com'
WHERE c_custName = 'Cheryl Mason'
OR c_custPhone = '132-564-9078'
OR c_custEmail = 'itgurlllheather@fakeemail.com';

-- Query 6: Delete Customer Information
DELETE FROM Customer
WHERE c_custName = 'Heather Mason'
OR c_custPhone = '123-654-7809'
OR c_custEmail = 'itgurlllcheryl@fakeemail.com';

-- * BOOK *
-- Query 7: Add New Book
INSERT INTO Book
VALUES ('BookID', 'Title', 'PublisherID','Genre',25.00,'New',Paperback);

-- Query 8: Update book price
Update Book
SET b_price = 20.0
WHERE b_title = 'Missing';

-- Query 9: Delete Book
DELETE FROM Book
WHERE b_bookID = 9
AND b_title = 'False Stars';

-- Query 10: Search by Price range
SELECT b_title, b_price
From Book
WHERE b_price < 30;

-- Query 11: Search by Author
SELECT Book.b_title, Author.a_authorName
FROM Book
JOIN Wrote ON Wrote.w_bookID = Book.b_bookID
JOIN Author ON Author.a_authorID = Wrote.w_authorID
WHERE Author.a_authorName = 'Giulia Yamada'
ORDER BY Book.b_title;

-- Query 12: Search by Genre
SELECT b_title, b_genre
From Book
Where b_genre = Romance
ORDER BY b_genre;

-- Query 13: Search by Title
SELECT b_title
From Book
Where b_title = 'Missing';

-- * ORDER/INVENTORY *
-- Query 14: Update book order
Update Orders
SET inTransit = 'Y', dateReceived = '11-15-2024'
WHERE BookID = '11' and  o_orderDate = '11-10-2024';

--Query 15: Update Inventory Quantity
UPDATE Inventory 
SET i_quantity = i_quantity + 20 
WHERE i_bookID = (SELECT b_bookID FROM Book WHERE b_title = 'The Adventures of Bigfoot');

--Query 16: Subtracts the inventory when a book is purchased;
UPDATE Inventory
SET i_quantity = Inventory.i_quantity - 1
WHERE i_bookID = (SELECT b_bookID FROM Book WHERE b_title = 'The Adventures of Bigfoot');

--Query 17: Best rated
SELECT Book.b_title, AVG(Rating.r_starRating) AS avg_rating
FROM Rating
JOIN Book ON Book.b_bookID = Rating.r_bookID
WHERE r_starRating >= 4
GROUP BY Book.b_title
ORDER BY avg_rating DESC;

--Query 18: Bestsellers
SELECT b_title AS Bestsellers
FROM Book
JOIN Orders ON Orders.o_bookID = Book.b_bookID
GROUP BY o_bookID
ORDER BY COUNT(o_bookID) DESC
LIMIT 3;

--Query 19: Inventory count check
SELECT Book.b_title, Inventory.i_quantity
FROM Inventory
JOIN Book ON Inventory.i_bookID = Book.b_bookID
WHERE Inventory.i_quantity < 5;

-- Query 20: Best Reviewed
SELECT b_title AS Best_Reviewed
FROM Book
JOIN Rating ON Rating.r_bookID = Book.b_bookID
GROUP BY r_bookID
ORDER BY AVG(r_starRating) DESC
LIMIT 3;

--Query 21: Gets info of all books
SELECT 
Book.b_title, 
Author.a_authorName, 
Publisher.p_publishingHouse, 
Book.b_genre, 
Book.b_price, 
Book.b_format, 
CASE WHEN Inventory.i_quantity > 0 THEN 'Available' ELSE 'Out of Stock' END AS availability,
Inventory.i_quantity
FROM Book
JOIN Wrote ON Wrote.w_bookID = Book.b_bookID
JOIN Author ON Author.a_authorID = Wrote.w_authorID
JOIN Publisher ON Publisher.p_publisherID = Book.b_publisherID
JOIN Inventory ON Inventory.i_bookID = Book.b_bookID

--Query 22: Updates customer info (python needed)
UPDATE Customer
SET 
    c_custName = COALESCE(?, c_custName),
    c_custPhone = COALESCE(?, c_custPhone)
WHERE c_custEmail = ?

--Query 23: Updates inventory
--(python needed)
UPDATE Inventory
SET i_quantity = ?
WHERE i_bookID = (SELECT b_bookID FROM Book WHERE b_title = ?)

--Query 24: Shows users book order info and book info
--(python needed)
SELECT 
o_orderNum AS Order_Number,
b_title AS Book_Name,
a_authorName AS Author_Name
FROM Orders
JOIN Customer ON Orders.o_custID = Customer.c_custID
JOIN Book ON Orders.o_bookID = Book.b_bookID
JOIN Wrote ON Book.b_bookID = Wrote.w_bookID
JOIN Author ON Wrote.w_authorID = Author.a_authorID
WHERE Customer.c_custEmail = ?