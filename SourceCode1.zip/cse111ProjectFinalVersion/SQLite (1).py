from flask import Flask, redirect, url_for, render_template, jsonify, request, session
import sqlite3
from sqlite3 import Error

app = Flask(__name__)

# Database connection functions
def openConnection(_dbFile):
    print("++++++++++++++++++++++++++++++++++")
    print("Attempting to open database:", _dbFile)

    conn = None
    try:
        conn = sqlite3.connect(_dbFile)
        print("Database connection successful")
    except Error as e:
        print("Error:", e)

    print("++++++++++++++++++++++++++++++++++")
    return conn

def closeConnection(_conn, _dbFile):
    print("++++++++++++++++++++++++++++++++++")
    print("Closing database:", _dbFile)

    try:
        _conn.close()
        print("Database closed successfully")
    except Error as e:
        print("Error:", e)

    print("++++++++++++++++++++++++++++++++++")

#route to mainPage
@app.route('/')
def home():
    return render_template('mainPage.html')

#route to login
@app.route('/login')
def login():
    return render_template('login.html')

#route to logout
@app.route('/logout')
def logout():
    session.clear()  
    return redirect(url_for('home'))  

#allows users to login. Accesses the database and
#compares the users email to the database from user input
@app.route('/account', methods=['POST'])
def loginAccount():
    email = request.form.get('email')  # Retrieve email from form
    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        query = "SELECT * FROM Customer WHERE c_custEmail = ?"
        print("Executing Query:", query)
        cursor.execute(query, (email,))
        user = cursor.fetchone()
        print("User Found:", user)  
        if user:
            session['email'] = email  # Store email in session
            return redirect(url_for('mainPageCustomer'))
        else:
            return render_template('login.html', error="Email not found")
    except Error as e:
        print("Error executing query:", e)
        return render_template('login.html', error="An error occurred")
    finally:
        closeConnection(conn, 'database.sqlite')

#routes to MainPageCustomer
@app.route('/mainPageCustomer')
def mainPageCustomer():
    return render_template('mainPageCustomer.html')

# Shows all book info in employee page
#query that gets all necessary columns
@app.route('/employee_page')
def employee_page():
    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        query = """
            SELECT 
                Book.b_title, 
                Author.a_authorName, 
                Publisher.p_publishingHouse, 
                Book.b_genre, 
                Book.b_price, 
                Book.b_format, 
                CASE WHEN Inventory.i_quantity > 0 THEN 'Available' ELSE 'Out of Stock' END AS availability,
                Inventory.i_quantity
            FROM Book
            JOIN Wrote ON Wrote.w_bookID = Book.b_bookID
            JOIN Author ON Author.a_authorID = Wrote.w_authorID
            JOIN Publisher ON Publisher.p_publisherID = Book.b_publisherID
            JOIN Inventory ON Inventory.i_bookID = Book.b_bookID
        """
        print("Executing Query:", query)
        cursor.execute(query)
        books = cursor.fetchall()
        print("Books Retrieved:", books)
    except Error as e:
        print("Error fetching books:", e)
        books = []
    finally:
        closeConnection(conn, 'database.sqlite')

    return render_template('mainPageEmployee.html', books=books)

#routes to modify employee page
@app.route('/modify_page')
def modify_page():
    return render_template('modifyBooks.html')

#modify price of books
#query that updates the price
@app.route('/modify_price', methods=['POST'])
def modify_price():
    book_title = request.form['bookTitle']
    new_price = request.form['price']
    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        query = "UPDATE Book SET b_price = ? WHERE b_title = ?"
        cursor.execute(query, (new_price, book_title))
        conn.commit()
    except Error as e:
        print("Error updating price:", e)
    finally:
        closeConnection(conn, 'database.sqlite')
    return redirect(url_for('modify_page'))

#modifies account info
# Update query of users info based on user input
@app.route('/modify_account', methods=['POST', 'GET'])
def modify_account():
    if 'email' not in session:
        return redirect(url_for('login'))  # Ensure the user is logged in

    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        if request.method == 'POST':
            # Retrieve values from the form, default to NULL if not provided
            cust_name = request.form.get('customerName') or None
            cust_phone = request.form.get('customerPhone') or None

            query = """
                UPDATE Customer
                SET 
                    c_custName = COALESCE(?, c_custName),
                    c_custPhone = COALESCE(?, c_custPhone)
                WHERE c_custEmail = ?
            """
            cursor.execute(query, (cust_name, cust_phone, session['email']))
            conn.commit()

    except Error as e:
        print("Error updating account:", e)
    finally:
        closeConnection(conn, 'database.sqlite')

    # Render the modify account page
    return render_template('modifyAccount.html')

#delete account
#query that searches for customer user input email and then
#deletes it
@app.route('/del_acct', methods=['GET', 'POST'])
def del_acct():
    if request.method == 'POST':
        email = request.form.get('email')
        conn = openConnection('database.sqlite')
        cursor = conn.cursor()
        try:
            # Check if the user exists
            query = "SELECT * FROM Customer WHERE c_custEmail = ?"
            print("Executing Query:", query)
            cursor.execute(query, (email,))
            user = cursor.fetchone()
            print("User Found:", user)  # Debugging log

            if user:
                # Corrected the SQL syntax for DELETE
                delete_stuff = "DELETE FROM Customer WHERE c_custEmail = ?"
                cursor.execute(delete_stuff, (email,))
                conn.commit()
                session.pop('email', None)  # Clear the session for the user
                return redirect(url_for('home'))  # Redirect to the homepage
            else:
                # If the email does not exist, show an error
                return render_template('del_acct.html', error="Email not found")
        except Error as e:
            print("Error executing query:", e)
            return render_template('del_acct.html', error="An error occurred")
        finally:
            closeConnection(conn, 'database.sqlite')
    return render_template('del_acct.html')


#update inventory
@app.route('/update_availability_quantity', methods=['POST'])
def update_quantity():
    book_title = request.form['bookTitle']
    quantity = request.form['quantity']
    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        query = """
            UPDATE Inventory
            SET i_quantity = ?
            WHERE i_bookID = (SELECT b_bookID FROM Book WHERE b_title = ?)
        """
        cursor.execute(query, (quantity, book_title))
        conn.commit()
    except Error as e:
        print("Error updating quantity:", e)
    finally:
        closeConnection(conn, 'database.sqlite')
    return redirect(url_for('modify_page'))

#add book
@app.route('/add_book', methods=['POST'])
def add_book():
    title = request.form['title']
    author = request.form['author']
    publisher = request.form['publisher']
    genre = request.form['genre']
    price = request.form['price']
    condition = request.form['condition'] 
    book_format = request.form['format']
    quantity = request.form['quantity']
    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        # Find or insert the author
        cursor.execute("SELECT a_authorID FROM Author WHERE a_authorName = ?", (author,))
        author_row = cursor.fetchone()
        if author_row:
            author_id = author_row[0]
        else:
            cursor.execute("SELECT MAX(a_authorID) FROM Author")
            last_author_id = cursor.fetchone()[0] or 0
            author_id = last_author_id + 1
            cursor.execute(
                "INSERT INTO Author (a_authorID, a_authorName) VALUES (?, ?)",
                (author_id, author),
            )

        # Find or insert the publisher
        cursor.execute("SELECT p_publisherID FROM Publisher WHERE p_publishingHouse = ?", (publisher,))
        publisher_row = cursor.fetchone()
        if publisher_row:
            publisher_id = publisher_row[0]
        else:
            cursor.execute("SELECT MAX(p_publisherID) FROM Publisher")
            last_publisher_id = cursor.fetchone()[0] or 0
            publisher_id = last_publisher_id + 1
            cursor.execute(
                "INSERT INTO Publisher (p_publisherID, p_publishingHouse) VALUES (?, ?)",
                (publisher_id, publisher),
            )

        # Find the next book ID
        cursor.execute("SELECT MAX(b_bookID) FROM Book")
        last_id = cursor.fetchone()[0] or 0
        next_id = last_id + 1

        # Insert the new book
        cursor.execute(
            """
            INSERT INTO Book (b_bookID, b_title, b_publisherID, b_genre, b_price, b_condition, b_format)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (next_id, title, publisher_id, genre, price, condition, book_format),
        )

        # Insert into Inventory with the new box ID (same as book ID)
        cursor.execute(
            """
            INSERT INTO Inventory (i_boxID, i_bookID, i_quantity)
            VALUES (?, ?, ?)
            """,
            (next_id, next_id, quantity),
        )

        # Link the author and book in the Wrote table
        cursor.execute(
            """
            INSERT INTO Wrote (w_authorID, w_bookID)
            VALUES (?, ?)
            """,
            (author_id, next_id),
        )

        conn.commit()
    except Error as e:
        print("Error adding new book:", e)
    finally:
        closeConnection(conn, 'database.sqlite')
    return redirect(url_for('modify_page'))

# Customer Orders
@app.route('/orders')
def orders():
    if 'email' not in session:
        return redirect(url_for('login'))

    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        query = """
            SELECT 
                o_orderNum AS Order_Number,
                b_title AS Book_Name,
                a_authorName AS Author_Name
            FROM Orders
            JOIN Customer ON Orders.o_custID = Customer.c_custID
            JOIN Book ON Orders.o_bookID = Book.b_bookID
            JOIN Wrote ON Book.b_bookID = Wrote.w_bookID
            JOIN Author ON Wrote.w_authorID = Author.a_authorID
            WHERE Customer.c_custEmail = ?
        """
        cursor.execute(query, (session['email'],))
        orders = cursor.fetchall()
    except Error as e:
        print("Error fetching orders:", e)
        orders = []
    finally:
        closeConnection(conn, 'database.sqlite')
    return render_template('Orders.html', orders=orders)

# Browsing Books for public
@app.route('/browse_books1')
def browse_books1():
    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        query = """
            SELECT 
                Book.b_title AS Title,
                GROUP_CONCAT(Author.a_authorName, ', ') AS Authors,
                Publisher.p_publishingHouse AS Publisher,
                Book.b_genre AS Genre,
                Book.b_price AS Price,
                Book.b_format AS Format,
                CASE 
                    WHEN Inventory.i_quantity > 0 THEN 'Available' 
                    ELSE 'Out of Stock' 
                END AS Availability,
                Inventory.i_quantity AS Quantity
            FROM Book
            JOIN Wrote ON Wrote.w_bookID = Book.b_bookID
            JOIN Author ON Author.a_authorID = Wrote.w_authorID
            JOIN Publisher ON Publisher.p_publisherID = Book.b_publisherID
            JOIN Inventory ON Inventory.i_bookID = Book.b_bookID
            GROUP BY Book.b_bookID
        """
        cursor.execute(query)
        books = cursor.fetchall()
        return render_template('browse1.html', books=books)
    except Error as e:
        print("Error fetching books:", e)
        return render_template('browse1.html', books=[])
    finally:
        closeConnection(conn, 'database.sqlite')

#browse books for user
@app.route('/browse_books2')
def browse_books2():
    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        query = """
            SELECT 
                Book.b_title AS Title,
                GROUP_CONCAT(Author.a_authorName, ', ') AS Authors,
                Publisher.p_publishingHouse AS Publisher,
                Book.b_genre AS Genre,
                Book.b_price AS Price,
                Book.b_format AS Format,
                CASE 
                    WHEN Inventory.i_quantity > 0 THEN 'Available' 
                    ELSE 'Out of Stock' 
                END AS Availability,
                Inventory.i_quantity AS Quantity
            FROM Book
            JOIN Wrote ON Wrote.w_bookID = Book.b_bookID
            JOIN Author ON Author.a_authorID = Wrote.w_authorID
            JOIN Publisher ON Publisher.p_publisherID = Book.b_publisherID
            JOIN Inventory ON Inventory.i_bookID = Book.b_bookID
            GROUP BY Book.b_bookID
        """
        cursor.execute(query)
        books = cursor.fetchall()
        return render_template('browse2.html', books=books)
    except Error as e:
        print("Error fetching books:", e)
        return render_template('browse2.html', books=[])
    finally:
        closeConnection(conn, 'database.sqlite')

# query that takes average of Ratings
@app.route('/best_selling')
def best_selling():
    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        query = """
            SELECT b_title AS Best_Reviewed
            FROM Book
            JOIN Rating ON Rating.r_bookID = Book.b_bookID
            GROUP BY r_bookID
            ORDER BY AVG(r_starRating) DESC
            LIMIT 3;
        """
        cursor.execute(query)
        results = cursor.fetchall()
    except Error as e:
        print("Error executing query:", e)
        results = []
    finally:
        closeConnection(conn, 'database.sqlite')
    return jsonify(results)


@app.route('/check_inventory')
def check_inventory():
    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        query = """
            SELECT Book.b_title, Inventory.i_quantity
            FROM Inventory
            JOIN Book ON Inventory.i_bookID = Book.b_bookID
            WHERE Inventory.i_quantity < 15;
        """
        cursor.execute(query)
        results = cursor.fetchall()
    except Error as e:
        print("Error fetching inventory:", e)
        results = []
    finally:
        closeConnection(conn, 'database.sqlite')
    return jsonify(results)

#query that searches database from user input
@app.route('/search_books', methods=['GET'])
def search_books():
    search_query = request.args.get('query')
    conn = openConnection('database.sqlite')
    cursor = conn.cursor()
    try:
        query = """
            SELECT b_title, Author.a_authorName, b_genre
            FROM Book
            JOIN Wrote on w_bookID = Book.b_bookID
            JOIN Author on a_authorID = w_authorID
            WHERE b_title LIKE ?
               OR Author.a_authorName LIKE ?
               OR b_genre LIKE ?
        """
        cursor.execute(query, (f"%{search_query}%", f"%{search_query}%", f"%{search_query}%"))
        results = cursor.fetchall()
    except Error as e:
        print("Error searching for books:", e)
        results = []
    finally:
        closeConnection(conn, 'database.sqlite')
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)
