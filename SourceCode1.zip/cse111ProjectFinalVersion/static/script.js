document.addEventListener('DOMContentLoaded', () => {
    // Generic fetch and update function
    const fetchAndDisplay = (url, callback) => {
        fetch(url)
            .then((response) => response.json())
            .then(callback)
            .catch((err) => console.error(`Error fetching ${url}:`, err));
    };

    // Handle login form submission
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = document.querySelector('input[name="email"]').value;
            fetch('/account', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email }),
            })
                .then((response) => response.json())
                .then((data) => {
                    if (data.message === "Login successful") {
                        window.location.href = '/mainPageCustomer';
                    } else {
                        document.getElementById('errorMessage').textContent = data.message;
                    }
                })
                .catch(() => {
                    document.getElementById('errorMessage').textContent = 'An error occurred. Please try again.';
                });
        });
    }

    // Show Best Rated Books
    const showBooksButton = document.getElementById('showBooks');
    if (showBooksButton) {
        showBooksButton.addEventListener('click', () => {
            fetchAndDisplay('/best_selling', (data) => {
                const content = data.map((row) => `<p>${row[0]}</p>`).join('');
                document.getElementById('results').innerHTML = `<br><h1><u>Best Rated</u></h1><br>${content}`;
            });
        });
    }

    // Fetch and display books in the browse table
    const browseBooksTable = document.querySelector('#browseTable tbody');
    if (browseBooksTable) {
        fetchAndDisplay('/browse_books', (data) => {
            browseBooksTable.innerHTML = data.map((book) => `
                <tr>
                    <td>${book[0]}</td>
                    <td>${book[1]}</td>
                    <td>${book[2]}</td>
                    <td>${book[3]}</td>
                    <td>${book[4]}</td>
                    <td>${book[5]}</td>
                    <td>${book[6]}</td>
                    <td>${book[7]}</td>
                </tr>
            `).join('');
        });
    }

    // Search for Books
    const searchForm = document.getElementById('searchForm');
    if (searchForm) {
        searchForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const query = document.querySelector('input[name="query"]').value;
            fetchAndDisplay(`/search_books?query=${encodeURIComponent(query)}`, (data) => {
                const content = data.map((row) => `<p>${row[0]} (${row[1]})</p>`).join('');
                document.getElementById('results').innerHTML = `<h1><u>Search Results</u></h1>${content}`;
            });
        });
    }
});
